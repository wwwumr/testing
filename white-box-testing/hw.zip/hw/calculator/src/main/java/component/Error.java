package component;

public class Error {
  private int error;

  public int getError() {
    return error;
  }

  public void setError(int error) {
    this.error = error;
  }
}
